curl http://localhost:8192/v1/completions \
 -H "Content-Type: application/json" \
 -d '{
       "model": "/models/Qwen3-0.6B",
       "prompt": "San Francisco is a",
       "max_tokens": 7,
       "temperature": 0
     }'
