import json
import random

def load_json(file_path):
    """Load JSON file"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def convert_aps(sample):
    """Convert APS data format"""
    return {
        'instruction': sample['instruction'],
        'input': sample['input'],
        'output': sample['output']
    }

def convert_arc(sample):
    """Convert ARC data format"""
    instruction = (
        f"You are given a snippet of {sample['language']} code that has a bug (status: {sample['original_status']}). "
        "Please fix the code so that it compiles and runs correctly."
    )
    input_text = (
        f"Problem ID: {sample['problem_id']}\n"
        f"Error message: {sample['error']}\n"
        f"Original code (lines {sample['i1']} to {sample['i2']}):\n"
        f"{sample['original_src']}"
    )
    output_text = (
        f"The type of change applied is: {sample['change']}.\n\n"
        f"The corrected code (modifying lines {sample['j1']} to {sample['j2']}) is as follows:\n"
        f"{sample['changed_src']}"
    )
    return {
        'instruction': instruction,
        'input': input_text,
        'output': output_text
    }

def convert_evol(sample):
    """Convert Evol data format"""
    return {
        'instruction': sample['instruction'],
        'input': "",
        'output': sample['output']
    }

def process_and_sample(raw_data, converter, n):
    """Convert and randomly sample data"""
    processed = [converter(d) for d in raw_data]
    random.shuffle(processed)
    return processed[:n]

def mix_datasets(aps_file, arc_file, evol_file, output_file, sample_size):
    """
    Mix multiple datasets and save to file
    :param aps_file: APS dataset file path
    :param arc_file: ARC dataset file path
    :param evol_file: Evol dataset file path
    :param output_file: Output file path
    :param sample_size: Total sample size for each dataset
    """
    # Sample size for each format
    sample_aps_size = sample_size // 3
    sample_arc_size = sample_size // 3
    sample_evol_size = sample_size // 3

    # Load data
    aps_data = load_json(aps_file)
    arc_data = load_json(arc_file)
    evol_data = load_json(evol_file)

    # Convert and sample
    processed_aps = process_and_sample(aps_data, convert_aps, sample_aps_size)
    processed_arc = process_and_sample(arc_data, convert_arc, sample_arc_size)
    processed_evol = process_and_sample(evol_data, convert_evol, sample_evol_size)

    # Merge and shuffle
    merged_data = processed_aps + processed_arc + processed_evol
    random.shuffle(merged_data)

    # Save to file
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(merged_data, f, indent=2, ensure_ascii=False)

    print(f"Dataset processing completed, saved as: {output_file}")

def check_json_structure(file_path):
    """
    Check the structure of a JSON file and print the total number of entries if it's a list.
    :param file_path: Path to the JSON file
    """
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        if isinstance(data, list):
            print("Total entries:", len(data))
        else:
            print("JSON structure is not an array, other methods are needed to count")

# Example call
if __name__ == "__main__":
    aps_file = 'Alpaca-pubmed-summarization/Aps_train.json'
    arc_file = 'archive/train.json'
    evol_file = 'Evol-Instruct-Code-80k-v1/EvolInstruct-Code-80k.json'
    sample_size = 3000
    output_file = f'output/mixed_dataset_{sample_size}.json'

    # average mixing of 3 datasets
    mix_datasets(aps_file, arc_file, evol_file, output_file, sample_size)

    check_json_structure(output_file)