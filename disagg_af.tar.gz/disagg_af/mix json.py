# -*- coding: gbk -*-
import json
import random

# �ļ�·��
aps_file = 'output/part_Aps5.json'
arc_file = 'output/part_arc100.json'
evol_file = 'output/part_Evol50.json'
output_file = 'output/mixed_dataset.json'

# ÿ�ָ�ʽ��������
sample_size = 3000
sample_aps_size = sample_size//3
sample_arc_size = sample_size//3
sample_evol_size = sample_size//3

# ��������
def load_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

aps_data = load_json(aps_file)
arc_data = load_json(arc_file)
evol_data = load_json(evol_file)

# ת��Ϊͳһ��ʽ
def convert_aps(sample):
    return {
        'instruction': sample['instruction'],
        # 'input': sample.get('input', ""),
        'input': sample['input'],
        'output': sample['output']
    }

def convert_arc(sample):
    instruction = (
        f"You are given a snippet of {sample['language']} code that has a bug (status: {sample['original_status']}). "
        "Please fix the code so that it compiles and runs correctly."
    )
    input_text = (
        f"Problem ID: {sample['problem_id']}\n"
        f"Error message: {sample['error']}\n"
        f"Original code (lines {sample['i1']} to {sample['i2']}):\n"
        f"{sample['original_src']}"
    )
    output_text = (
        f"The type of change applied is: {sample['change']}.\n\n"
        f"The corrected code (modifying lines {sample['j1']} to {sample['j2']}) is as follows:\n"
        f"{sample['changed_src']}"
    )
    return {
        'instruction': instruction,
        'input': input_text,
        'output': output_text
    }

def convert_evol(sample):
    return {
        'instruction': sample['instruction'],
        'input': "",
        'output': sample['output']
    }

# ת��+�������
def process_and_sample(raw_data, converter, n):
    processed = [converter(d) for d in raw_data]
    random.shuffle(processed)
    return processed[:n]

# ����ÿ�����ݼ�
processed_aps = process_and_sample(aps_data, convert_aps, sample_aps_size)
processed_arc = process_and_sample(arc_data, convert_arc, sample_arc_size)
processed_evol = process_and_sample(evol_data, convert_evol, sample_evol_size)

# �ϲ����������
merged_data = processed_aps + processed_arc + processed_evol
random.shuffle(merged_data)

# ���浽�ļ�
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(merged_data, f, indent=2, ensure_ascii=False)

print(f"���ݼ������ɣ�����Ϊ��{output_file}")
