import json
import os

def split_json_array(input_file, output_dir, chunk_size=1000):
    
    os.makedirs(output_dir, exist_ok=True)
    
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)  
        
    total = len(data)
    print(f"total: {total}")
    # part_num = 0
    
    # for i in range(0, total, chunk_size):
    #     part_num += 1
    #     chunk = data[i:i+chunk_size]
    #     output_path = os.path.join(output_dir, f'part_{part_num}.json')
        
    #     with open(output_path, 'w', encoding='utf-8') as f_out:
    #         json.dump(chunk, f_out, indent=2, ensure_ascii=False)
            
    # print("divide json done")

    base_name = os.path.splitext(os.path.basename(input_file))[0]
    
    chunk = data[:chunk_size]
    output_path = os.path.join(output_dir, f'{base_name}_{chunk_size}.json')
    
    with open(output_path, 'w', encoding='utf-8') as f_out:
        json.dump(chunk, f_out, indent=2, ensure_ascii=False)
            
    print("divide json done")

if __name__ == "__main__":
    print("start")
    # split_json_array('Alpaca-pubmed-summarization/train/train.json', 'output', chunk_size=5000)
    # split_json_array('Evol-Instruct-Code-80k-v1/EvolInstruct-Code-80k.json', 'output', chunk_size=5000)
    # split_json_array('archive/train.json', 'output', chunk_size=5000) 
    input_file = '/share/lq/datasets/Aps_train.json'
    output_dir = '/share/lq/datasets'
    chunk_size = 1
    
    split_json_array(input_file, output_dir, chunk_size=chunk_size)
    
    print("finish")